package Bowling;

//Used to label the types of rolls
public enum shotType {
	Strike, Spare, GutterBall, None
}
